from tkinter import *
import math

# ---------------------------- CONSTANTS ------------------------------- #
PINK = "#e2979c"
RED = "#e7305b"
GREEN = "#9bdeac"
YELLOW = "#f7f5dd"
FONT_NAME = "Courier"
WORK_MIN = 1
SHORT_BREAK_MIN = 1
LONG_BREAK_MIN = 1
repeticiones = 0
contador_checkmarks = 0
evento_after = None
# ---------------------------- TIMER RESET ------------------------------- # 
def reset_countdown():
    global repeticiones
    global contador_checkmarks
    ventana.after_cancel(evento_after)
    repeticiones = 0
    contador_checkmarks = 0
    etiqueta_timer.config(text="Temporizador")
    etiqueta_cnt_pomodoros.config(text=contador_checkmarks)
    canvas.itemconfig(texto_canvas, text="00:00")
# ---------------------------- TIMER MECHANISM ------------------------------- # 

def llamar_countdown():
    global repeticiones
    work_minutes = WORK_MIN * 60
    short_break_minutes = SHORT_BREAK_MIN * 60
    long_break_minutes = LONG_BREAK_MIN * 60

    repeticiones += 1

    if repeticiones % 2 == 1:
           countdown(work_minutes)
           etiqueta_timer.config(text=" Trabajando ",fg=GREEN)
    elif repeticiones == 8:
           countdown(long_break_minutes)
           etiqueta_timer.config(text="  Descanso  ",fg=PINK)
    elif repeticiones % 2 == 0:
           countdown(short_break_minutes)
           etiqueta_timer.config(text="Descansando", fg=RED)



# ---------------------------- COUNTDOWN MECHANISM ------------------------------- # 

def countdown(count):
    global contador_checkmarks
    global evento_after
    cuenta_min  = math.floor(count / 60)
    cuenta_seg  = count % 60

    if cuenta_seg < 10:
        cuenta_seg = "0" + str(cuenta_seg)

    canvas.itemconfig(texto_canvas,text=f"{cuenta_min}:{cuenta_seg}")

    if count > 0:
        evento_after = ventana.after(100,countdown,count - 1)
    else:
        if repeticiones % 2 == 1 or repeticiones == 1:
            contador_checkmarks +=1
            checkmarks = "✓" * contador_checkmarks
            etiqueta_cnt_pomodoros.config(text=checkmarks)
        llamar_countdown()





# ---------------------------- UI SETUP ------------------------------- #

ventana = Tk()
ventana.title('Reloj Pomodoro')
ventana.config(padx=20,pady=60,bg=YELLOW)
ventana.minsize(width=500,height=500)
ventana.maxsize(width=500,height=500)




etiqueta_timer = Label(text="Temporizador",font=(FONT_NAME,30,"bold"),fg=GREEN,bg=YELLOW)
etiqueta_timer.grid(column=1,row=0)


canvas = Canvas(width=220,height=244,bg=YELLOW,highlightthickness=0)
img_tomate = PhotoImage(file='tomato.png')
canvas.create_image(110,122,image=img_tomate)
texto_canvas = canvas.create_text(120,145,text="",font=(FONT_NAME,32,"bold"),fill='white')
canvas.grid(column=1,row=1)



boton_comenzar = Button(text="Comenzar",command=llamar_countdown)
boton_comenzar.grid(column=0,row=2)

boton_detener = Button(text="Detener",command=reset_countdown)
boton_detener.grid(column=2,row=2)



etiqueta_cnt_pomodoros = Label(text="",bg=YELLOW,font=(FONT_NAME,32,"bold"))
etiqueta_cnt_pomodoros.grid(column=1,row=3)

ventana.mainloop()